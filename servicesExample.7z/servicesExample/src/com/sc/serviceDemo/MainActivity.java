﻿
package com.sc.serviceDemo;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

import com.sc.service.MsgService;
import com.sc.servicesexample.R;


public class MainActivity extends Activity
{
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}
	
	// 启动服务
	public void startService(View v)
	{
		MsgService.GetInstance().start(this, MsgService.class);
	}
	
	// 暂时停止服务，服务逻辑会在应用退出后自行重启，并一直运行
	public void stopService(View v)
	{
		MsgService.GetInstance().stop();
	}
	
}
